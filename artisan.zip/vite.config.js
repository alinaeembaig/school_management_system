import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
    plugins: [
        laravel({
            input: 'resources/js/app.js',
            refresh: true,
        }),
        vue({
            template: {
                transformAssetUrls: {
                    base: null,
                    includeAbsolute: false,
                },
                server: {
                    port: 3000,
                    https: true,
                    hmr: {
                        host: "localhost:8001",
                        port: 3001,
                        protocol: "wss",
                    },
                },
            },
        }),
    ],
});
